#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include "GameCamera.h"

struct ObjectTransform
{
public:
	ObjectTransform(const glm::vec3& pos = glm::vec3(), const glm::vec3& rot = glm::vec3(), const glm::vec3& scale = glm::vec3(1.0f, 1.0f, 1.0f)) //Constructor for the transform class. responsible for initialising position, rotation, and scale
	{
		this->positionVector = pos; //Sets the position vector
		this->rotationVector = rot; //Sets the rotation vector 
		this->scaleVector = scale; //Sets the scale vector
	}

	inline glm::mat4 RetrieveModel() const //Retrieves and returns a matrix that represents a transform model of an object
	{
		glm::mat4 posMat = glm::translate(positionVector);
		glm::mat4 scaleMat = glm::scale(scaleVector);
		glm::mat4 rotX = glm::rotate(rotationVector.x, glm::vec3(1.0, 0.0, 0.0));
		glm::mat4 rotY = glm::rotate(rotationVector.y, glm::vec3(0.0, 1.0, 0.0));
		glm::mat4 rotZ = glm::rotate(rotationVector.z, glm::vec3(0.0, 0.0, 1.0));
		glm::mat4 rotMat = rotX * rotY * rotZ;

		return posMat * rotMat * scaleMat; //Combines and returns the position, rotation, and scale matrices 
	}

	/*inline glm::mat4 GetMVP(const Camera& camera) const
	{
		glm::mat4 VP = camera.GetViewProjection();
		glm::mat4 M = GetModel();

		return VP * M;//camera.GetViewProjection() * GetModel();
	}*/

	inline glm::vec3* RetrievePosition() { return &positionVector; } //Obtains the transform position vector
	inline glm::vec3* RetrieveRotation() { return &rotationVector; } //Obtains the transform rotation vector
	inline glm::vec3* RetrieveScale() { return &scaleVector; } //Obtains the transform scale vector

	inline void SetPosition(glm::vec3& pos) { this->positionVector = pos; } //Sets the position vector
	inline void SetRotation(glm::vec3& rot) { this->rotationVector = rot; } //Sets the rotation vector
	inline void SetScale(glm::vec3& scale) { this->scaleVector = scale; } //Sets the scale vector
protected:
private:
	glm::vec3 positionVector;//Stores the position vector
	glm::vec3 rotationVector; //Stores the rotation vector
	glm::vec3 scaleVector; //Stores the scale vector
};


