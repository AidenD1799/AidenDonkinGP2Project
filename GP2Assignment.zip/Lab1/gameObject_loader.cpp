#include "gameObject_loader.h"
#include <fstream>
#include <iostream>
#include <algorithm>
#include <map>

static bool CompareOBJIndexPtr(const gameObjectIndex* a, const gameObjectIndex* b);
static inline unsigned int FindNextChar(unsigned int start, const char* str, unsigned int length, char token);
static inline unsigned int ParseOBJIndexValue(const std::string& token, unsigned int start, unsigned int end);
static inline float ParseOBJFloatValue(const std::string& token, unsigned int start, unsigned int end);
static inline std::vector<std::string> SplitString(const std::string &s, char delim);

gameObjectModel::gameObjectModel(const std::string& fileName) //Constructor for the game object model class
{
	UVCheck = false;
	normalsCheck = false;
    std::ifstream file;
    file.open(fileName.c_str());

    std::string line;
    if(file.is_open())
    {
        while(file.good())
        {
            getline(file, line);
        
            unsigned int lineLength = line.length();
            
            if(lineLength < 2)
                continue;
            
            const char* lineCStr = line.c_str();
            
            switch(lineCStr[0])
            {
                case 'v':
                    if(lineCStr[1] == 't')
                        this->gameObjectUVs.push_back(ParseOBJVec2(line));
                    else if(lineCStr[1] == 'n')
                        this->gameObjectNormals.push_back(ParseOBJVec3(line));
                    else if(lineCStr[1] == ' ' || lineCStr[1] == '\t')
                        this->gameObjectVertices.push_back(ParseOBJVec3(line));
                break;
                case 'f':
                    CreateOBJFace(line);
                break;
                default: break;
            };
        }
    }
    else
    {
        std::cerr << "Unable to load mesh: " << fileName << std::endl; //Error thrown when model has failed to load from file
    }
}

void IndexedObjectModel::CalculateObjectNormals() //Calculates and stores the normals of the object model
{
    for(unsigned int i = 0; i < requiredIndices.size(); i += 3)
    {
        int i0 = requiredIndices[i];
        int i1 = requiredIndices[i + 1];
        int i2 = requiredIndices[i + 2];

        glm::vec3 v1 = positionVectors[i1] - positionVectors[i0];
        glm::vec3 v2 = positionVectors[i2] - positionVectors[i0];
        
        glm::vec3 normal = glm::normalize(glm::cross(v1, v2));
            
        objectNormals[i0] += normal;
        objectNormals[i1] += normal;
        objectNormals[i2] += normal;
    }
    
    for(unsigned int i = 0; i < positionVectors.size(); i++)
        objectNormals[i] = glm::normalize(objectNormals[i]);
}

IndexedObjectModel gameObjectModel::ToIndexedModel()
{
    IndexedObjectModel result;
    IndexedObjectModel normalModel;
    
    unsigned int numIndices = gameObjectIndices.size();
    
    std::vector<gameObjectIndex*> indexLookup;
    
    for(unsigned int i = 0; i < numIndices; i++)
        indexLookup.push_back(&gameObjectIndices[i]);
    
    std::sort(indexLookup.begin(), indexLookup.end(), CompareOBJIndexPtr);
    
    std::map<gameObjectIndex, unsigned int> normalModelIndexMap;
    std::map<unsigned int, unsigned int> indexMap;
    
    for(unsigned int i = 0; i < numIndices; i++)
    {
        gameObjectIndex* currentIndex = &gameObjectIndices[i];
        
        glm::vec3 currentPosition = gameObjectVertices[currentIndex->objectVertexIndex];
        glm::vec2 currentTexCoord;
        glm::vec3 currentNormal;
        
        if(UVCheck)
            currentTexCoord = gameObjectUVs[currentIndex->objectUVIndex];
        else
            currentTexCoord = glm::vec2(0,0);
            
        if(normalsCheck)
            currentNormal = gameObjectNormals[currentIndex->objectNormalIndex];
        else
            currentNormal = glm::vec3(0,0,0);
        
        unsigned int normalModelIndex;
        unsigned int resultModelIndex;
        
        //Create model to properly generate normals on
        std::map<gameObjectIndex, unsigned int>::iterator it = normalModelIndexMap.find(*currentIndex);
        if(it == normalModelIndexMap.end())
        {
            normalModelIndex = normalModel.positionVectors.size();
        
            normalModelIndexMap.insert(std::pair<gameObjectIndex, unsigned int>(*currentIndex, normalModelIndex));
            normalModel.positionVectors.push_back(currentPosition);
            normalModel.textureCoordinates.push_back(currentTexCoord);
            normalModel.objectNormals.push_back(currentNormal);
        }
        else
            normalModelIndex = it->second;
        
        //Create model which properly separates texture coordinates
        unsigned int previousVertexLocation = FindLastVertexIndex(indexLookup, currentIndex, result);
        
        if(previousVertexLocation == (unsigned int)-1)
        {
            resultModelIndex = result.positionVectors.size();
        
            result.positionVectors.push_back(currentPosition);
            result.textureCoordinates.push_back(currentTexCoord);
            result.objectNormals.push_back(currentNormal);
        }
        else
            resultModelIndex = previousVertexLocation;
        
        normalModel.requiredIndices.push_back(normalModelIndex);
        result.requiredIndices.push_back(resultModelIndex);
        indexMap.insert(std::pair<unsigned int, unsigned int>(resultModelIndex, normalModelIndex));
    }
    
    if(!normalsCheck)
    {
        normalModel.CalculateObjectNormals();
        
        for(unsigned int i = 0; i < result.positionVectors.size(); i++)
            result.objectNormals[i] = normalModel.objectNormals[indexMap[i]];
    }
    
    return result;
};

unsigned int gameObjectModel::FindLastVertexIndex(const std::vector<gameObjectIndex*>& indexLookup, const gameObjectIndex* currentIndex, const IndexedObjectModel& result) //Method responsible for locating returning the last vertex index
{
    unsigned int start = 0;
    unsigned int end = indexLookup.size();
    unsigned int current = (end - start) / 2 + start;
    unsigned int previous = start;
    
    while(current != previous)
    {
        gameObjectIndex* testIndex = indexLookup[current];
        
        if(testIndex->objectVertexIndex == currentIndex->objectVertexIndex)
        {
            unsigned int countStart = current;
        
            for(unsigned int i = 0; i < current; i++)
            {
                gameObjectIndex* possibleIndex = indexLookup[current - i];
                
                if(possibleIndex == currentIndex)
                    continue;
                    
                if(possibleIndex->objectVertexIndex != currentIndex->objectVertexIndex)
                    break;
                    
                countStart--;
            }
            
            for(unsigned int i = countStart; i < indexLookup.size() - countStart; i++)
            {
                gameObjectIndex* possibleIndex = indexLookup[current + i];
                
                if(possibleIndex == currentIndex)
                    continue;
                    
                if(possibleIndex->objectVertexIndex != currentIndex->objectVertexIndex)
                    break;
                else if((!UVCheck || possibleIndex->objectUVIndex == currentIndex->objectUVIndex) 
                    && (!normalsCheck || possibleIndex->objectNormalIndex == currentIndex->objectNormalIndex))
                {
                    glm::vec3 currentPosition = gameObjectVertices[currentIndex->objectVertexIndex];
                    glm::vec2 currentTexCoord;
                    glm::vec3 currentNormal;
                    
                    if(UVCheck)
                        currentTexCoord = gameObjectUVs[currentIndex->objectUVIndex];
                    else
                        currentTexCoord = glm::vec2(0,0);
                        
                    if(normalsCheck)
                        currentNormal = gameObjectNormals[currentIndex->objectNormalIndex];
                    else
                        currentNormal = glm::vec3(0,0,0);
                    
                    for(unsigned int j = 0; j < result.positionVectors.size(); j++)
                    {
                        if(currentPosition == result.positionVectors[j] 
                            && ((!UVCheck || currentTexCoord == result.textureCoordinates[j])
                            && (!normalsCheck || currentNormal == result.objectNormals[j])))
                        {
                            return j;
                        }
                    }
                }
            }
        
            return -1;
        }
        else
        {
            if(testIndex->objectVertexIndex < currentIndex->objectVertexIndex)
                start = current;
            else
                end = current;
        }
    
        previous = current;
        current = (end - start) / 2 + start;
    }
    
    return -1;
}

void gameObjectModel::CreateOBJFace(const std::string& line) //Method responsible for creating an object face
{
    std::vector<std::string> tokens = SplitString(line, ' ');

    this->gameObjectIndices.push_back(ParseOBJIndex(tokens[1], &this->UVCheck, &this->normalsCheck));
    this->gameObjectIndices.push_back(ParseOBJIndex(tokens[2], &this->UVCheck, &this->normalsCheck));
    this->gameObjectIndices.push_back(ParseOBJIndex(tokens[3], &this->UVCheck, &this->normalsCheck));

    if((int)tokens.size() > 4)
    {
        this->gameObjectIndices.push_back(ParseOBJIndex(tokens[1], &this->UVCheck, &this->normalsCheck));
        this->gameObjectIndices.push_back(ParseOBJIndex(tokens[3], &this->UVCheck, &this->normalsCheck));
        this->gameObjectIndices.push_back(ParseOBJIndex(tokens[4], &this->UVCheck, &this->normalsCheck));
    }
}

gameObjectIndex gameObjectModel::ParseOBJIndex(const std::string& token, bool* hasUVs, bool* hasNormals)
{
    unsigned int tokenLength = token.length();
    const char* tokenString = token.c_str();
    
    unsigned int vertIndexStart = 0;
    unsigned int vertIndexEnd = FindNextChar(vertIndexStart, tokenString, tokenLength, '/');
    
    gameObjectIndex result;
    result.objectVertexIndex = ParseOBJIndexValue(token, vertIndexStart, vertIndexEnd);
    result.objectUVIndex = 0;
    result.objectNormalIndex = 0;
    
    if(vertIndexEnd >= tokenLength)
        return result;
    
    vertIndexStart = vertIndexEnd + 1;
    vertIndexEnd = FindNextChar(vertIndexStart, tokenString, tokenLength, '/');
    
    result.objectUVIndex = ParseOBJIndexValue(token, vertIndexStart, vertIndexEnd);
    *hasUVs = true;
    
    if(vertIndexEnd >= tokenLength)
        return result;
    
    vertIndexStart = vertIndexEnd + 1;
    vertIndexEnd = FindNextChar(vertIndexStart, tokenString, tokenLength, '/');
    
    result.objectNormalIndex = ParseOBJIndexValue(token, vertIndexStart, vertIndexEnd);
    *hasNormals = true;
    
    return result;
}

glm::vec3 gameObjectModel::ParseOBJVec3(const std::string& line) 
{
    unsigned int tokenLength = line.length();
    const char* tokenString = line.c_str();
    
    unsigned int vertIndexStart = 2;
    
    while(vertIndexStart < tokenLength)
    {
        if(tokenString[vertIndexStart] != ' ')
            break;
        vertIndexStart++;
    }
    
    unsigned int vertIndexEnd = FindNextChar(vertIndexStart, tokenString, tokenLength, ' ');
    
    float x = ParseOBJFloatValue(line, vertIndexStart, vertIndexEnd);
    
    vertIndexStart = vertIndexEnd + 1;
    vertIndexEnd = FindNextChar(vertIndexStart, tokenString, tokenLength, ' ');
    
    float y = ParseOBJFloatValue(line, vertIndexStart, vertIndexEnd);
    
    vertIndexStart = vertIndexEnd + 1;
    vertIndexEnd = FindNextChar(vertIndexStart, tokenString, tokenLength, ' ');
    
    float z = ParseOBJFloatValue(line, vertIndexStart, vertIndexEnd);
    
    return glm::vec3(x,y,z);

    //glm::vec3(atof(tokens[1].c_str()), atof(tokens[2].c_str()), atof(tokens[3].c_str()))
}

glm::vec2 gameObjectModel::ParseOBJVec2(const std::string& line)
{
    unsigned int tokenLength = line.length();
    const char* tokenString = line.c_str();
    
    unsigned int vertIndexStart = 3;
    
    while(vertIndexStart < tokenLength)
    {
        if(tokenString[vertIndexStart] != ' ')
            break;
        vertIndexStart++;
    }
    
    unsigned int vertIndexEnd = FindNextChar(vertIndexStart, tokenString, tokenLength, ' ');
    
    float x = ParseOBJFloatValue(line, vertIndexStart, vertIndexEnd);
    
    vertIndexStart = vertIndexEnd + 1;
    vertIndexEnd = FindNextChar(vertIndexStart, tokenString, tokenLength, ' ');
    
    float y = ParseOBJFloatValue(line, vertIndexStart, vertIndexEnd);
    
    return glm::vec2(x,y);
}

static bool CompareOBJIndexPtr(const gameObjectIndex* a, const gameObjectIndex* b)
{
    return a->objectVertexIndex < b->objectVertexIndex;
}

static inline unsigned int FindNextChar(unsigned int start, const char* str, unsigned int length, char token)
{
    unsigned int result = start;
    while(result < length)
    {
        result++;
        if(str[result] == token)
            break;
    }
    
    return result;
}

static inline unsigned int ParseOBJIndexValue(const std::string& token, unsigned int start, unsigned int end)
{
    return atoi(token.substr(start, end - start).c_str()) - 1;
}

static inline float ParseOBJFloatValue(const std::string& token, unsigned int start, unsigned int end)
{
    return atof(token.substr(start, end - start).c_str());
}

static inline std::vector<std::string> SplitString(const std::string &s, char delim)
{
    std::vector<std::string> elems;
        
    const char* cstr = s.c_str();
    unsigned int strLength = s.length();
    unsigned int start = 0;
    unsigned int end = 0;
        
    while(end <= strLength)
    {
        while(end <= strLength)
        {
            if(cstr[end] == delim)
                break;
            end++;
        }
            
        elems.push_back(s.substr(start, end - start));
        start = end + 1;
        end = start;
    }
        
    return elems;
}
