#pragma once
#include <SDL\SDL.h>
#include <GL/glew.h>
#include <SDL/SDL_mixer.h>
#include "GameDisplay.h" 
#include "ObjectShader.h"
#include "ObjectMesh.h"
#include "ObjectTexture.h"
#include "ObjectTransform.h"
#include "SDLApplicationAudio.h"
#include "DeltaTime.h"

enum class GameState{PLAY, EXIT};

class MainGame
{
public:
	MainGame(); //Constructor for the application
	~MainGame(); //Destructor for the application

	void run(); //Begins the application when called

private:

	void setupSystems(); //Initialises the application systems when starting the game
	void processInput();
	void gameLoop(); //Responsible for updating events within the game
	void drawGame(); //Creates the visual display for the game 
	void checkMouseInput(SDL_MouseMotionEvent mouseMovement);
	bool collisionCheck(glm::vec3 m1Pos, float m1Rad, glm::vec3 m2Pos, float m2Rad); //Detects any collisions between two chosen objects
	void checkUserInput(SDL_Keysym inputKey);

	GameDisplay applicationDisplay; //Display for the application
	GameState _gameState; //Stores the current state of the game 
	ObjectMesh object1Mesh;//The mesh of the first game object
	ObjectMesh object2Mesh; //The mesh of the second game object
	ObjectMesh object3Mesh; //The mesh of the third game object
	GameCamera applicationCamera; //The camera used for the application
	ObjectShader objectShader; //Shader required for visual display of game objects
	SDLApplicationAudio applicationAudio; //Audio system for the application 
	ObjectTexture texture; //Textures for game objects
	ObjectTexture texture1; //''
	ObjectTexture texture2; //''
	DeltaTime deltaTime;

	float counter;
	unsigned int whistle;
	unsigned int backGroundMusic;
};

