#include "ObjectTexture.h"
#include "stb_image.h"
#include <cassert>
#include <iostream>

ObjectTexture::ObjectTexture()
{
	
}

ObjectTexture::~ObjectTexture() //Destructor for the object texture class
{
	glDeleteTextures(1, &textureController); //Number of and address of textures
}

void ObjectTexture::BindTexture(unsigned int unit) //Method responsible for binding object textures
{
	assert(unit >= 0 && unit <= 31); /// Check we are working with one of the 32 textures

	glActiveTexture(GL_TEXTURE0 + unit); //Set active texture unit
	glBindTexture(GL_TEXTURE_2D, textureController); //Type of and texture to bind to unit
}

void ObjectTexture::setupTexture(const std::string& file)
{
	int width, height, numComponents; //Width, height, and number of components of image
	unsigned char* imageData = stbi_load((file).c_str(), &width, &height, &numComponents, 4); //Loads the image and stores the data

	if (imageData == NULL)
	{
		std::cerr << "Texture failed to load" << file << std::endl; //Error message printed to user on unsuccessful file load
	}

	glGenTextures(1, &textureController); // Number of and address of textures
	glBindTexture(GL_TEXTURE_2D, textureController); //Bind texture - define type 

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); // Wrap texture outside width
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); // Wrap texture outside height

	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // Linear filtering for minification (texture is smaller than area)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); // Linear filtering for magnifcation (texture is larger)

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, imageData); //Target, Mipmapping Level, Pixel Format, Width, Height, Border Size, Input Format, Data Type of Texture, Image Data

	stbi_image_free(imageData);
}

