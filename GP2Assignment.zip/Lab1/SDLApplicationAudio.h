#pragma once
#include <SDL/SDL_mixer.h>
#include <SDL/SDL.h>
#include <iostream>
#include <vector>

class SDLApplicationAudio
{
	public:
		SDLApplicationAudio(); //Constructor for audio class
		~SDLApplicationAudio();//Destructor for audio class
		
		void insertSoundEffect(const char* path); //Loads an audio effect from project files
		void insertAudioTrack(const char* path); //Loads an audio track from project files
		void triggerSoundEffect(const int which) const; //Triggers a pre-loaded sound effect
		void triggerAudioTrack(); //Triggers a pre-loaded audio track

	private:
		Mix_Music* backgroundMusicTrack; //Variable used to store an audio track for background music
		std::vector<Mix_Chunk*> mSoundEffectStorage; //Variable used to store sound effects
};

