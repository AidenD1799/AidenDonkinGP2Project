#pragma once
#include <SDL/SDL.h>
#include <GL\glew.h>
#include <iostream>
#include <string>
using namespace std;


class GameDisplay
{
public:
	GameDisplay(); //Constructor for the game display class
	~GameDisplay(); //Destructor for the game display class
	void setupGameDisplay(); //Responsible for initialising the game display
	void changeBuffer(); //Swaps the buffers
	void resetDisplay(float red, float green, float blue, float alpha); //Clears the screen display

	float retrieveWidth(); //Obtains the width of the display
	float retrieveHeight(); //Obtains the height of the display

private:

	void throwError(std::string errorMessage); //Presents an error message to the player
	
	SDL_GLContext sdlGLContext; //Global variable to hold the context
	SDL_Window* sdlGameWindow; //Holds pointer to game window
	float gameScreenWidth; //Stores the screen width
	float gameScreenHeight; //Stores the screen height
};

