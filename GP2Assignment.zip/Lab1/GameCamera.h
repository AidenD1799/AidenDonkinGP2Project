#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>

struct GameCamera
{
public:
	GameCamera() //Struct constructor 
	{
	}

	void setupCamera(const glm::vec3& position, float fieldOfView, float aspectRatio, float nearClip, float farClip) //Initialises the variables which define the camera object
	{
		this->positionVector = position;
		this->forwardVector = glm::vec3(0.0f, 0.0f, 1.0f);
		this->upwardVector = glm::vec3(0.0f, 1.0f, 0.0f);
		this->projectionMatrix = glm::perspective(fieldOfView, aspectRatio, nearClip, farClip);
	}

	glm::vec3 retrievePosition() //Returns the current position of the camera game object
	{
		return this->positionVector;
	}

	inline glm::mat4 retrieveViewProjection() const //Returns the current view project through the use of the projection matrix
	{
		return projectionMatrix * glm::lookAt(positionVector, positionVector + forwardVector, upwardVector);
	}

	void MoveForward(float amt)
	{
		positionVector += forwardVector * amt;
	}

	void MoveRight(float amt)
	{
		positionVector += glm::cross(upwardVector, forwardVector) * amt;
	}

	void CameraPitch(float angle)
	{
		glm::vec3 right = glm::normalize(glm::cross(upwardVector, forwardVector));

		forwardVector = glm::vec3(glm::normalize(glm::rotate(angle, right) * glm::vec4(forwardVector, 0.0)));
		upwardVector = glm::normalize(glm::cross(forwardVector, right));
	}

	void RotateCameraY(float angle)
	{
		static const glm::vec3 UP(0.0f, 1.0f, 0.0f);

		glm::mat4 rotation = glm::rotate(angle, UP);

		forwardVector = glm::vec3(glm::normalize(rotation * glm::vec4(forwardVector, 0.0)));
		upwardVector = glm::vec3(glm::normalize(rotation * glm::vec4(upwardVector, 0.0)));
	}

protected:
private:
	glm::mat4 projectionMatrix; //Matrix which allows transition from camera space to screen space
	glm::vec3 positionVector; //Stores the current position of the camera
	glm::vec3 forwardVector; //Vector which stores the forwards direction
	glm::vec3 upwardVector;//Vector which stores the upwards direction
};


