#pragma once
#include <glm\glm.hpp>
#include <GL\glew.h>
#include <string>
#include "gameObject_loader.h"

struct Vertex
{
public:
	Vertex(const glm::vec3& pos, const glm::vec2& texCoord) //Constructor method responsible for initialising the vector class
	{
		this->vertexPosition = pos; //Sets the vertex position
		this->vertextTextureCoordinate = texCoord; //Sets the vertex texture coordinate
		this->vertexNormal = vertexNormal; //Sets the vertex normal
	}

	glm::vec3* RetrieveVertexPosition() { return &vertexPosition; } //Retrieves the position vector for the vertex
	glm::vec2* RetrieveTextureCoordinate() { return &vertextTextureCoordinate; } //Retrieves the texture coordinate for the vertex
	glm::vec3* RetrieveVertexNormal() { return &vertexNormal; } //Retrieves the normal vector for the vertex

private:
	glm::vec3 vertexPosition; //Stores the position vector
	glm::vec2 vertextTextureCoordinate; //Stores the texture coordinate vector
	glm::vec3 vertexNormal; //Stores the normal vector
};

struct Sphere
{
public:

	Sphere()//Constructor for sphere struct
	{}

	glm::vec3 RetrieveSpherePosition() { return spherePos; } //Retrieves position of sphere
	float RetrieveRadius() { return sphereRadius; } //Retrieves radius of sphere

	void SetSpherePosition(glm::vec3 pos) //Sets the position of the sphere
	{
		this->spherePos = pos;
	}

	void SetSphereRadius(float radius) //Sets the radius of the sphere
	{
		this->sphereRadius = radius;
	}

private:
	glm::vec3 spherePos; //Vector responsible for storing sphere position
	float sphereRadius; //Float responsible for storing sphere radius
};

class ObjectMesh
{
public:
	ObjectMesh(); //Class constructor
	~ObjectMesh(); //Class destructor


	void drawMesh();
	void setupMesh(Vertex* vertices, unsigned int numVertices, unsigned int* indices, unsigned int numIndices); //Initialises the object meshes
	void loadObjectModel(const std::string& filename); //Loads the specified mesh from the project files
	void setupObjectModel(const IndexedObjectModel& model); //Initialises the object model
	void overwriteSphereData(glm::vec3 pos, float radius); //Updates the current sphere position and radius
	glm::vec3 retrieveSpherePosition() { return meshSphereObject.RetrieveSpherePosition(); } //Obtains the current sphere position
	float retrieveSphereRadius() { return meshSphereObject.RetrieveRadius(); } //Obtains the current sphere radius

private:



	enum
	{
		POSITION_VERTEXBUFFER,
		TEXCOORD_VB,
		NORMAL_VB,
		INDEX_VB,
		NUM_BUFFERS
	};

	Sphere meshSphereObject;
	GLuint VAObject;
	GLuint VABuffers[NUM_BUFFERS]; //Create our array of buffers
	unsigned int drawProgress; //How much of the vertexArrayObject do we want to draw
};