#ifndef GAMEOBJECT_LOADER_H_INCLUDED
#define GAMEOBJECT_LOADER_H_INCLUDED

#include <glm/glm.hpp>
#include <vector>
#include <string>

struct gameObjectIndex
{
    unsigned int objectVertexIndex;
    unsigned int objectUVIndex;
    unsigned int objectNormalIndex;
    
    bool operator<(const gameObjectIndex& r) const { return objectVertexIndex < r.objectVertexIndex; }
};

class IndexedObjectModel
{
public:
    std::vector<glm::vec3> positionVectors; //Stores the position vectors of a game object
    std::vector<glm::vec2> textureCoordinates; //Stores the texture coordinates of a game object
    std::vector<glm::vec3> objectNormals; //Stores the normal vectors of a game object
    std::vector<unsigned int> requiredIndices;
    
    void CalculateObjectNormals();
};

class gameObjectModel
{
public:
    std::vector<gameObjectIndex> gameObjectIndices;
    std::vector<glm::vec3> gameObjectVertices;
    std::vector<glm::vec2> gameObjectUVs;
    std::vector<glm::vec3> gameObjectNormals;
    bool UVCheck;
    bool normalsCheck;
    
    gameObjectModel(const std::string& fileName);
    
    IndexedObjectModel ToIndexedModel();
private:
    unsigned int FindLastVertexIndex(const std::vector<gameObjectIndex*>& indexLookup, const gameObjectIndex* currentIndex, const IndexedObjectModel& result);
    void CreateOBJFace(const std::string& line);
    
    glm::vec2 ParseOBJVec2(const std::string& line);
    glm::vec3 ParseOBJVec3(const std::string& line);
    gameObjectIndex ParseOBJIndex(const std::string& token, bool* hasUVs, bool* hasNormals);
};

#endif // OBJ_LOADER_H_INCLUDED
