#include <iostream>
#include "MainGame.h"

int main(int argc, char** argv) //argument used to call SDL main
{
	MainGame mainGame; //Creates an instance of the main game to load
	mainGame.run(); //Runs the application

	return 0;
}