#include "MainGame.h"
#include "GameCamera.h"
#include <iostream>
#include <string>
#include "DeltaTime.h"


ObjectTransform objectTransform;

MainGame::MainGame()
{
	_gameState = GameState::PLAY; //Sets the current game state to "PLAY"
	GameDisplay* _gameDisplay = new GameDisplay(); //Initialises a new game display
    ObjectMesh* mesh1(); //Initialises the object meshes
	ObjectMesh* mesh2(); //''
	ObjectMesh* mesh3(); //''
}

MainGame::~MainGame() //Main game destructor
{
}

void MainGame::run() //Method called to begin the game loop and setup basic application features
{
	setupSystems(); 
	gameLoop();
}

void MainGame::setupSystems() //Method is responsible for loading audio, shaders, camera, and object meshes
{
	applicationDisplay.setupGameDisplay(); 
	applicationAudio.insertAudioTrack("..\\res\\background.wav"); //Loads the background music into the application, making it ready to play when requred


	object1Mesh.loadObjectModel("..\\res\\apple_obj.obj"); //Loads the desired 3D model from the project files for the object mesh
	object2Mesh.loadObjectModel("..\\res\\wreath_cookie_obj.obj"); //''
	object3Mesh.loadObjectModel("..\\res\\memorycard.obj");//''

	texture.setupTexture("..\\res\\lowpolytexture.jpg"); //Loads first texture from project files
	texture1.setupTexture("..\\res\\water.jpg"); //Loads second texture from project files
	texture2.setupTexture("..\\res\\mcard.jpg"); //Loads third texture from project files
	
	applicationCamera.setupCamera(glm::vec3(0, 0, -5), 70.0f, (float)applicationDisplay.retrieveWidth()/applicationDisplay.retrieveHeight(), 0.01f, 1000.0f); //Sets up the application camera with the desired height and width 

	objectShader.setupShader("..\\res\\shader"); //Loads a new shader into the application

	counter = 1.0f; //Responsible for updating the movement of the 3D game objects
	applicationAudio.insertSoundEffect("..\\res\\chimes.wav"); //Loads a sound effect into the application that will serve as a collision noise 
}

void MainGame::gameLoop() // Method is called when the game is in PLAY state
{
	while (_gameState != GameState::EXIT) //Runs until the game is exited 
	{
		deltaTime.SetUpDeltaTime();
		applicationAudio.triggerAudioTrack(); //Plays the background audio track
		processInput();
		drawGame(); //Renders the visuals for the game
		collisionCheck(object1Mesh.retrieveSpherePosition(), object1Mesh.retrieveSphereRadius(), object2Mesh.retrieveSpherePosition(), object2Mesh.retrieveSphereRadius()); //Checks for collisions between objects
		collisionCheck(object1Mesh.retrieveSpherePosition(), object1Mesh.retrieveSphereRadius(), object3Mesh.retrieveSpherePosition(), object3Mesh.retrieveSphereRadius()); //''
		collisionCheck(object2Mesh.retrieveSpherePosition(), object2Mesh.retrieveSphereRadius(), object3Mesh.retrieveSpherePosition(), object3Mesh.retrieveSphereRadius());//''
		
	}
}

void MainGame::checkUserInput(SDL_Keysym inputKey) //Used to check if the user input has any effect on the camera
{
	float moveDistance = 5.0f; //Distance the camera will move by
	switch (inputKey.sym)
	{
	case SDLK_w:
		applicationCamera.MoveForward(moveDistance); //Moves the camera forward
		break;
	case SDLK_d:
		applicationCamera.MoveRight(moveDistance); //Moves the camera right
		break;
	case SDLK_s:
		applicationCamera.MoveForward(-moveDistance); //Moves the camera backwards
		break;
	case SDLK_a:
		applicationCamera.MoveRight(-moveDistance); //Moves the camera left
		break;
	}
}

void MainGame::checkMouseInput(SDL_MouseMotionEvent mouseMovement)
{
	applicationCamera.CameraPitch(mouseMovement.xrel * 0.001);
	applicationCamera.RotateCameraY(mouseMovement.yrel * 0.001);
}

void MainGame::processInput() //This method is responsible for tracking game events such as quitting the game
{
	SDL_Event gameEvent;

	while(SDL_PollEvent(&gameEvent)) //Retreieves and process events
	{
		switch (gameEvent.type)
		{
			case SDL_QUIT:
				_gameState = GameState::EXIT; //Updates the game state to EXIT
				break;
			case SDL_MOUSEMOTION:
				this->checkMouseInput(gameEvent.motion);
				break;
			case SDL_KEYDOWN: //Reads keyboard input from the user
				this->checkUserInput(gameEvent.key.keysym); //Passes the key into the check user input function

		}
	}
	
}


bool MainGame::collisionCheck(glm::vec3 m1Pos, float m1Rad, glm::vec3 m2Pos, float m2Rad) //Method is responsible for detecting collisions between objects 
{
	float distance = ((m2Pos.x - m1Pos.x)*(m2Pos.x - m1Pos.x) + (m2Pos.y - m1Pos.y)*(m2Pos.y - m1Pos.y) + (m2Pos.z - m1Pos.z)*(m2Pos.z - m1Pos.z));			 //Retrieves the current distance between the two previously specified game objects 
	
	if (distance*distance < (m1Rad + m2Rad)) //Checks if a collision has occured
	{
		
		applicationAudio.triggerSoundEffect(0); //Plays the collision sound effect
		cout << distance << '\n'; //Prints the distance at which a collision has occured
		return true;
	}
	else
	{
		return false;
	}
}


void MainGame::drawGame() //Method responsible for rendering the application visuals 
{
	applicationDisplay.resetDisplay(0.0f, 0.0f, 0.0f, 1.0f); //Resets the visual display
	
	objectTransform.SetPosition(glm::vec3(sinf(counter) *5 * 0.25, -sinf(counter), 0)); //Sets the position of the first game object
	objectTransform.SetRotation(glm::vec3(0.0, 0.0, counter * 0.25)); //Sets the rotation of the first game object
	objectTransform.SetScale(glm::vec3(0.3, 0.3, 0.3)); //Sets the scale of the first game object
	
	

	objectShader.BindShaders(); //Binds the shaders to the game object
	objectShader.UpdateShaders(objectTransform, applicationCamera); //Updates the shaders for this specific game object
	texture.BindTexture(0); //Binds the correct texture to the game object
	object1Mesh.drawMesh(); //Draws the 3D object previously specified for this specific game object
	object1Mesh.overwriteSphereData(*objectTransform.RetrievePosition(), 0.1f); //Updates the object data with the current position of the object
	

	objectTransform.SetPosition(glm::vec3(sinf(counter), sinf(counter), 0)); //Sets the position of the second game object
	objectTransform.SetRotation(glm::vec3(0.0, 0.0, counter * 0.25)); //Sets the rotation of the second game object
	objectTransform.SetScale(glm::vec3(4, 4, 4)); //Sets the scale of the second game object

	objectShader.BindShaders(); //Binds the shaders to the game object
	objectShader.UpdateShaders(objectTransform, applicationCamera); //Updates the shaders for this specific game object
	texture1.BindTexture(0); //Binds the correct texture to the game object
	object2Mesh.drawMesh(); //Draws the 3D object previously specified for this specific game object
	object2Mesh.overwriteSphereData(*objectTransform.RetrievePosition(), 0.1f); //Updates the object data with the current position of the object

	objectTransform.SetPosition(glm::vec3(cosf(counter) * 5 * 0.25, 0.5 *0.25, cosf(counter-60)* 0.25 )); //Sets the position of the third game object
	objectTransform.SetRotation(glm::vec3(90, 0.0, -counter * 0.25)); //Sets the rotation of the third game object
	objectTransform.SetScale(glm::vec3(0.2, 0.2, 0.2)); //Sets the scale of the third game object

	objectShader.BindShaders(); //Binds the shaders to the game object
	objectShader.UpdateShaders(objectTransform, applicationCamera); //Updates the shaders for this specific game object
	texture2.BindTexture(0); //Binds the correct texture to the game object
	object3Mesh.drawMesh(); //Draws the 3D object previously specified for this specific game object
	object3Mesh.overwriteSphereData(*objectTransform.RetrievePosition(), 0.2f); //Updates the object data with the current position of the object

	counter = counter + 0.005f;//Updates the value of the counter which results in position and rotation changes for the objects 

				
	glEnableClientState(GL_COLOR_ARRAY); 
	glEnd();

	applicationDisplay.changeBuffer(); //Swaps the buffers
} 