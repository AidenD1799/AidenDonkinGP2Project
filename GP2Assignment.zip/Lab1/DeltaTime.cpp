#include "DeltaTime.h"
#include <SDL/SDL.h>

void DeltaTime::SetUpDeltaTime()
{
	float previousTime;

	
	previousTime = presentTime;

	presentTime = SDL_GetPerformanceCounter();

	deltaTimeVariable = (double)((presentTime = previousTime) / (double)SDL_GetPerformanceCounter());
}

float DeltaTime::RetrieveDeltaTime()
{
	return deltaTimeVariable;
}