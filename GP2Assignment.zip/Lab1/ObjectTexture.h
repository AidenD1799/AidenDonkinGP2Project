#pragma once
#include <string>
#include <GL\glew.h>

class ObjectTexture
{
public:
	ObjectTexture(); //Constructor for class

	void BindTexture(unsigned int unit); // bind upto 32 textures

	~ObjectTexture(); //Destructor for class

	void setupTexture(const std::string& file);

protected:
private:

	GLuint textureController; //Declares a private variable used for texture setup
};

