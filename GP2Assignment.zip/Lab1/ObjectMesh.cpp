#include "ObjectMesh.h"
#include <vector>


void ObjectMesh::setupMesh(Vertex* vertices, unsigned int numVertices, unsigned int* indices, unsigned int numIndices) //Method responsible for initialising object meshes 
{
	IndexedObjectModel model;

	for (unsigned int i = 0; i < numVertices; i++)
	{
		model.positionVectors.push_back(*vertices[i].RetrieveVertexPosition()); //Retrieves the position vectors of the model
		model.textureCoordinates.push_back(*vertices[i].RetrieveTextureCoordinate()); //Retrieves the texture coordinates of the model
		model.objectNormals.push_back(*vertices[i].RetrieveVertexNormal()); //Retrieves the normals of the model
	}

	for (unsigned int i = 0; i < numIndices; i++)
		model.requiredIndices.push_back(indices[i]);

	setupObjectModel(model);
}

void ObjectMesh::setupObjectModel(const IndexedObjectModel& model) //Method responsible for creating and binding vertex array objects
{

	drawProgress = model.requiredIndices.size();

	glGenVertexArrays(1, &VAObject); //Generate a vertex array and store it in the VAO
	glBindVertexArray(VAObject); //Bind the VAO (any operation that works on a VAO will work on our bound VAO - binding)

	glGenBuffers(NUM_BUFFERS, VABuffers); //Generate our buffers based of our array of data/buffers - GLuint vertexArrayBuffers[NUM_BUFFERS];

	glBindBuffer(GL_ARRAY_BUFFER, VABuffers[POSITION_VERTEXBUFFER]); //Tells opengl what type of data the buffer is (GL_ARRAY_BUFFER), and passes the data
	glBufferData(GL_ARRAY_BUFFER, model.positionVectors.size() * sizeof(model.positionVectors[0]), &model.positionVectors[0], GL_STATIC_DRAW); //Move the data to the GPU - type of data, size of data, starting address (pointer) of data, where do we store the data on the GPU (determined by type)
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

	glBindBuffer(GL_ARRAY_BUFFER, VABuffers[TEXCOORD_VB]); //Tells opengl what type of data the buffer is (GL_ARRAY_BUFFER), and passes the data
	glBufferData(GL_ARRAY_BUFFER, model.positionVectors.size() * sizeof(model.textureCoordinates[0]), &model.textureCoordinates[0], GL_STATIC_DRAW); //Move the data to the GPU - type of data, size of data, starting address (pointer) of data, where do we store the data on the GPU
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);

	glBindBuffer(GL_ARRAY_BUFFER, VABuffers[NORMAL_VB]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(model.objectNormals[0]) * model.objectNormals.size(), &model.objectNormals[0], GL_STATIC_DRAW);
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, 0);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VABuffers[INDEX_VB]); //Tells opengl what type of data the buffer is (GL_ARRAY_BUFFER), and passes the data
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, model.requiredIndices.size() * sizeof(model.requiredIndices[0]), &model.requiredIndices[0], GL_STATIC_DRAW); //Move the data to the GPU - type of data, size of data, starting address (pointer) of data, where do we store the data on the GPU

	glBindVertexArray(0); // Unbinds the VAO
}

ObjectMesh::ObjectMesh() //Class constructor
{
	drawProgress = NULL; //Resets the draw progress
}

void ObjectMesh::loadObjectModel(const std::string& filename) //Loads a 3D object mesh from the project files
{
	IndexedObjectModel model = gameObjectModel(filename).ToIndexedModel();
	setupObjectModel(model);
	Sphere meshSphere();
}

ObjectMesh::~ObjectMesh() //Class destructor 
{
	glDeleteVertexArrays(1, &VAObject); //Delete VAOs
}

void ObjectMesh::drawMesh() //Method responsible for visually rendering the specified 3D object
{
	glBindVertexArray(VAObject);

	glDrawElements(GL_TRIANGLES, drawProgress, GL_UNSIGNED_INT, 0);
	//glDrawArrays(GL_TRIANGLES, 0, drawCount);

	glBindVertexArray(0);
}

void ObjectMesh::overwriteSphereData(glm::vec3 pos, float radius) //Updates the position and radius of the 3D object 
{
	meshSphereObject.SetSpherePosition(pos);
	meshSphereObject.SetSphereRadius(radius);
}

