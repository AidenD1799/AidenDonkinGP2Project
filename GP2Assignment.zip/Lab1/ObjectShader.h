#pragma once
#include <string>
#include <GL\glew.h>
#include "ObjectTransform.h"
#include "GameCamera.h"

class ObjectShader
{
public:
	ObjectShader(); //Constructor for class

	void BindShaders(); //Set gpu to use our shaders
	void UpdateShaders(const ObjectTransform& transform, const GameCamera& camera); 
	void setupShader(const std::string& filename);

	std::string ObjectShader::LoadObjectShader(const std::string& fileName); //Method used for loading of shader from project files
	void ObjectShader::ShaderErrorCheck(GLuint shader, GLuint flag, bool isProgram, const std::string& errorMessage); //Method used for error detection
	GLuint ObjectShader::CreateObjectShader(const std::string& text, unsigned int type); //Method used for creation of shader

    ~ObjectShader(); //Destructor for class


protected:
private:
	static const unsigned int shaderCount = 2; // Number of shaders

	enum
	{
		TRANSFORM_U,

		NUM_UNIFORMS
	};

	GLuint shaderProgram; // Track the shader program
	GLuint shaderArray[shaderCount]; //Array of shaders
	GLuint uniformsArray[NUM_UNIFORMS]; //Number of uniform variables
};
