#include "SDLApplicationAudio.h"

SDLApplicationAudio::SDLApplicationAudio() //Constructor for the class
{
    // init sound
    //SDL_Init(SDL_INIT_AUDIO); // we don't actually need this step as its in the Display class

    int audio_rate = 22050; //Used to define the frequency of the audio mix
    Uint16 audio_format = AUDIO_S16SYS; //Defines the audio format
    int audio_channels = 2; //Defines the number of audio channels present in application
    int audio_buffers = 4096; //Used to define the chunk size of the audio mix

    if (Mix_OpenAudio(audio_rate, audio_format, audio_channels, audio_buffers) != 0)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Couldn't initialise audio: %s", Mix_GetError()); //Presents error to the user when audio fails to initialise correctly
        exit(-1);
    }
}

SDLApplicationAudio::~SDLApplicationAudio() //Destructor for the the class
{
    SDL_Quit(); //Exits the application
}

void SDLApplicationAudio::insertSoundEffect(const char* path) //Method responsible for loading sound effects from project files
{
    Mix_Chunk* tmpChunk = Mix_LoadWAV(path);

    if (tmpChunk != nullptr)
    {
        mSoundEffectStorage.push_back(tmpChunk);
        std::cout << (mSoundEffectStorage.size() - 1) << " Sound is Ready, path: " << path << '\n'; //Notifies the user that the audio files have loaded successfully
    }
    else
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Couldn't initialise audio: %s", Mix_GetError()); //Error message presented to user when audio files fail to load
    }
}

void SDLApplicationAudio::insertAudioTrack(const char* path) //Method responsible for loading audio tracks from project files
{
    backgroundMusicTrack = Mix_LoadMUS(path);

    if (backgroundMusicTrack == NULL)
    {
        printf("Failed to load beat music! SDL_mixer Error: %s\n", Mix_GetError()); //Error message presented to user when audio files fail to load
    }
}

void SDLApplicationAudio::triggerSoundEffect(const int which) const //Method responsible for triggering sound effect during running of game
{
    if (which > mSoundEffectStorage.size() - 1)
    {
        std::cout << "Sound out of range.\n"; //Error thrown if sound is not initialised correctly
        return;
    }
    
    Mix_PlayChannel(-1, mSoundEffectStorage[which], 0); //Plays the desired sound effect

    std::cout << "Played Sound: " << which << '\n'; //Notifies the user of which sound has been played
}

void SDLApplicationAudio::triggerAudioTrack() //Method responsible for triggering background music at beginning of game
{
    if (Mix_PlayingMusic() == 0)
    {
        //Play the music
        Mix_PlayMusic(backgroundMusicTrack, -1);
    }
}
