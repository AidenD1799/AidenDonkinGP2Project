#include "GameDisplay.h"


GameDisplay::GameDisplay() //Constructor for the game display class
{
	sdlGameWindow = nullptr; //Initialise to generate null access violation for debugging. 
	gameScreenWidth = 1024.0f; //Sets the screen width 
	gameScreenHeight = 768.0f; //Sets the screen height
}

GameDisplay::~GameDisplay() //Destructor for the game display class
{
	SDL_GL_DeleteContext(sdlGLContext); // Deletes the GL context
	SDL_DestroyWindow(sdlGameWindow); // Deletes the game window
	SDL_Quit(); //Exits the application
}

float GameDisplay::retrieveWidth() { return gameScreenWidth; } //Obtains and returns the screen width
float GameDisplay::retrieveHeight() { return gameScreenHeight; }//Obtains and returns the screen height

void GameDisplay::throwError(std::string errorString) //Used to present error messages to the user
{
	std::cout << errorString << std::endl;
	std::cout << "press any  key to quit...";
	int in;
	std::cin >> in;
	SDL_Quit(); //Exits the application
}

void GameDisplay::changeBuffer()
{
	SDL_GL_SwapWindow(sdlGameWindow); //Swaps the buffers
}

void GameDisplay::resetDisplay(float red, float green, float blue, float alpha) //Clears the screen display
{
	glClearColor(red, green, blue, alpha);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //Clears both the colour and depth buffers
}

void GameDisplay::setupGameDisplay()
{
	SDL_Init(SDL_INIT_EVERYTHING); //Initalises everything

	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8); //Sets the red colour attribute
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);//Sets the green colour attribute
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8); //Sets the blue colour attribute
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);// Sets the depth buffer
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1); //Sets the double buffer   

	sdlGameWindow = SDL_CreateWindow("Game Window", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, (int)gameScreenWidth, (int)gameScreenHeight, SDL_WINDOW_OPENGL); //Creates a game window for the application

	if (sdlGameWindow == nullptr)
	{
		throwError("Game window creation unsuccessful"); //Informs the user that there has been an error during window creation
	}

	sdlGLContext = SDL_GL_CreateContext(sdlGameWindow); //Creates a GL context

	if (sdlGLContext == nullptr)
	{
		throwError("SDL_GL context creation unsuccessful"); //Informs the user that there has been an error during context creation
	}

	GLenum error = glewInit();
	if (error != GLEW_OK)
	{
		throwError("GLEW initialisation unsuccessful"); //Informs the user that there has been an error during GLEW initialisation
	}

	glEnable(GL_DEPTH_TEST); //Enables z-buffering 
	glEnable(GL_CULL_FACE); //Prevents faces being drawn that face away from the camera

	glClearColor(0.0f, 1.0f, 1.0f, 1.0f);//Clears the screen colour
}