#pragma once
class DeltaTime
{
public:
	void SetUpDeltaTime();
	float RetrieveDeltaTime();

	float deltaTimeVariable;
	float presentTime = 0;
};

